﻿using System.Reflection;

[assembly: AssemblyTitle("Sensibo_Elements")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Sensibo_Elements")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2023")]
[assembly: AssemblyVersion("1.0.0.*")]

