﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;

namespace Sensibo_Elements_Integration
{
	#region Delegates
	public delegate void DelegateFn(short temperature, short feels_like, ushort humidity, SimplSharpString temperature_unit,
	 SimplSharpString tvoc, SimplSharpString co2, SimplSharpString pm25, SimplSharpString etoh, SimplSharpString iaq);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Sensibo_Elements
	{
		public DelegateFn callback_fn { get; set; }

		#region Declarations
		private string API_Key;
		private string Device_ID;
		private string Current_Temperature_Unit = string.Empty;
		private static Debug_Options Debug;
		#endregion

		public Sensibo_Elements()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public void Initialize(string Device_ID, string API_Key, string Default_Temperature_Unit, short Debug)
		{
			#region Save Parameters
			this.API_Key = API_Key;
			this.Device_ID = Device_ID;
			if (Current_Temperature_Unit == string.Empty)
			{
				Current_Temperature_Unit = Default_Temperature_Unit;
			}
			#endregion

			Set_Debug_Message_Output(Debug);

			Refresh();

			Debug_Message("Initialize", "SUCCESS");
		}

		//****************************************************************************************
		// 
		//  Refresh	-	Get Device status
		// 
		//****************************************************************************************
		public void Refresh()
		{
			string url = "";
			double d;
			short temperature = 0;
			short feels_like = 0;
			ushort humidity = 0;

			Debug_Message("Refresh", "Start");

			#region Error Checking
			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Elements - Refresh - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Elements - Refresh - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			#endregion

			#region Create url
			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "?fields=*&apiKey=" + API_Key;
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Elements - Refresh - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					Debug_Message("Refresh", "ContentString = " + response.ContentString);

					#region Parse json
					string s = response.ContentString;
					string temperature_S = Parse_Data_Substring(s, "\"measurements\":", "\"temperature\":", ",");
					string humidity_S = Parse_Data_Substring(s, "\"measurements\":", "\"humidity\":", ",");
					string feels_like_S = Parse_Data_Substring(s, "\"measurements\":", "\"feelsLike\":", ",");
					string tvoc = Parse_Data_Substring(s, "\"measurements\":", "\"tvoc\":", ",");
					string co2 = Parse_Data_Substring(s, "\"measurements\":", "\"co2\":", ",");
					string pm25 = Parse_Data_Substring(s, "\"measurements\":", "\"pm25\":", ",");
					string etoh = Parse_Data_Substring(s, "\"measurements\":", "\"etoh\":", ",");
					string iaq = Parse_Data_Substring(s, "\"measurements\":", "\"iaq\":", "}");
					#endregion

					#region Temperature
					if (string.IsNullOrEmpty(temperature_S) == false)
					{
						d = double.Parse(temperature_S);
						if (Current_Temperature_Unit == "F")
						{
							d = (d * 1.8) + 32;//convert from celcius to fahrenheit
						}
						temperature = (short)Math.Round(d, 0);
					}
					#endregion

					#region Feels Like
					if (string.IsNullOrEmpty(feels_like_S) == false)
					{
						d = double.Parse(feels_like_S);
						if (Current_Temperature_Unit == "F")
						{
							d = (d * 1.8) + 32;//convert from celcius to fahrenheit
						}
						feels_like = (short)Math.Round(d, 0);
					}
					#endregion

					#region Humidity
					if (string.IsNullOrEmpty(humidity_S) == false)
					{
						d = double.Parse(humidity_S);
						humidity = (ushort)Math.Round(d, 0);
					}
					#endregion

					callback_fn(temperature, feels_like, humidity, Current_Temperature_Unit, tvoc, co2, pm25, etoh, iaq);
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Elements - Refresh - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//Reporting of not finding section or string as an error eliminted because 
			//there are too many situations where the code has to accomodate the fact
			//that hubitat will send back very different messages depending on exactly
			//what setting was changed on a device.  Thermostat is the prime example

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Hubitat-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Sensibo_Elements - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Sensibo_Elements - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Sensibo_Elements.Debug = Debug_Options.None;
					break;

				case 1:
					Sensibo_Elements.Debug = Debug_Options.Console;
					break;

				case 2:
					Sensibo_Elements.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Sensibo_Elements.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 200;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Sensibo_Elements - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Sensibo_Elements - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
